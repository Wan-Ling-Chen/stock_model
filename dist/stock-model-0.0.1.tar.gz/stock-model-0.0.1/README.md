# ORM mapping Model #

* Only Model & SQL , no any business logic here.